@echo off
cd server
call npm install
start ""%CD%/node_modules/.bin/npm.exe start
cd ..\client
call npm install
start ""%CD%/node_modules/.bin/npm.exe start
