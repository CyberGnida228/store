// server/index.js
const express = require('express');
const app = express();
app.use(express.json());
let tasks = [];
app.get('/health', (req, res) => res.json({ ok: true }));
app.get('/tasks', (req, res) => res.json(tasks));
app.post('/tasks', (req, res) => {
  const t = Object.assign({ id: 't' + Date.now() }, req.body);
  tasks.push(t);
  res.status(201).json(t);
});
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server on http://localhost:' + PORT));
