#!/bin/bash
set -e
cd server
npm install
npm start &
SERVER=$!
cd ../client
npm install
npm start &
CLIENT=$!
wait $SERVER $CLIENT
