import React, { useEffect, useState } from 'react';

export default function App() {
  const [tasks, setTasks] = useState<any[]>([]);
  useEffect(() => {
    fetch('http://localhost:5000/tasks')
      .then(r => r.json())
      .then(setTasks)
      .catch(() => {});
  }, []);
  return (
    <div style={{ padding: 20 }}>
      <h1>Todo List (Minimal)</h1>
      <ul>
        {tasks.map(t => <li key={t.id}>{t.title || 'Untitled'} - {t.id}</li>)}
      </ul>
    </div>
  );
}
